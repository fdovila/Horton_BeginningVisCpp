*****************************************************************
Thank you for downloading the exercise solutions for 
          "Beginning Visual C++ 2012".
*****************************************************************
The code for solutions that involve more that one file are in their own folder within the chapter folder. All Windows solutions in Chapters 13 to 17 are Visual Studio 2012 projects. You can open any of these by clicking the *.sln file. You should then be able to build and run the example. 

The solutions for chapters 2 through 10 and 13 through 17 are included, and the solutions for each chapter is in its own ZIP archive. The solutions for Chapter 13 are text in a Readme.txt file. There are no exercises for Chapters 1, 11, and 18. Chapter 12 has exercises but because of the nature of these exercises, no solutions are necessary.

With solutions that are more complicated, I have included individual Readme.txt files that explain what I did in the code.

